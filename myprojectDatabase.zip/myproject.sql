-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2022 at 12:00 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `claims`
--

CREATE TABLE `claims` (
  `CliamID` int(10) UNSIGNED NOT NULL,
  `customerID` int(11) DEFAULT NULL,
  `OrderId` int(11) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL,
  `dttm` datetime DEFAULT current_timestamp(),
  `status` varchar(30) DEFAULT NULL,
  `details` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `postcode` varchar(5) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(150) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `userlevel` varchar(10) DEFAULT 'member'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `address`, `postcode`, `username`, `password`, `phone`, `created_at`, `userlevel`) VALUES
(1, 'jiraporn', 'jiraporn.jh@gmail.com', 'Bangkok', '10240', 'jiraporn', '$2y$10$2pRU9sMK2zj8/shq8XZDEuXF9HLtUgMZ2adYxA.oC.ffoMlcDSIsu', '0953954854', '2022-10-26 19:29:43', 'member'),
(5, 'test', 'system@gmail.com', 'test', '10210', 'system@gmail.com', '$2y$10$m299y1orU3ZGt1892t73k.u1W9/ce4sD/aeT2HWZMU9usHSBR.kQ2', '0953954854', '2022-12-17 15:53:44', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `new_id` int(10) UNSIGNED NOT NULL,
  `topic` varchar(50) NOT NULL,
  `detail` varchar(200) NOT NULL,
  `dttm` datetime DEFAULT current_timestamp(),
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`new_id`, `topic`, `detail`, `dttm`, `image`) VALUES
(1, 'เตรียมวางจำหน่ายข้าวหอมมะลิ105', 'เตรียมวางจำหน่ายข้าวหอมมะลิ105เตรียมวางจำหน่ายข้าวหอมมะลิ105เตรียมวางจำหน่ายข้าวหอมมะลิ105', '2022-10-26 19:47:32', 'upload/5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `o_id` int(10) NOT NULL,
  `dttm` datetime NOT NULL,
  `address` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `postcode` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `total` float NOT NULL,
  `gmail` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `id_customer` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `tracking_number` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`o_id`, `dttm`, `address`, `postcode`, `name`, `phone`, `total`, `gmail`, `status`, `id_customer`, `tracking_number`) VALUES
(42, '2022-12-21 04:04:06', 'Bangkok', '10240', 'jiraporn', '0953954854', 384, 'jiraporn.jh@gmail.com', 'รอการชำระเงิน', '1', 'tets'),
(41, '2022-12-21 04:03:21', 'Bangkok', '10240', 'jiraporn', '0953954854', 250, 'jiraporn.jh@gmail.com', 'รอการชำระเงิน', '1', NULL),
(40, '2022-12-09 02:46:39', 'Bangkok', '10240', 'jiraporn', '0953954854', 140, 'jiraporn.jh@gmail.com', 'รอการชำระเงิน', '1', NULL),
(39, '2022-12-08 06:47:05', 'Bangkok', '10240', 'jiraporn', '0953954854', 35, 'jiraporn.jh@gmail.com', 'รอการจัดส่ง', '1', NULL),
(38, '2022-10-26 14:51:15', 'Bangkok', '10240', 'jiraporn', '0953954854', 35, 'jiraporn.jh@gmail.com', 'รอการจัดส่ง', '1', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `d_id` int(10) NOT NULL,
  `o_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `pricetotal` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`d_id`, `o_id`, `p_id`, `qty`, `pricetotal`) VALUES
(1, 38, 1, 1, 35),
(2, 39, 1, 1, 35),
(3, 40, 1, 4, 140),
(4, 41, 3, 1, 250),
(5, 42, 4, 4, 384);

-- --------------------------------------------------------

--
-- Table structure for table `pays`
--

CREATE TABLE `pays` (
  `PayID` int(10) UNSIGNED NOT NULL,
  `customerID` int(11) DEFAULT NULL,
  `image` varchar(250) DEFAULT NULL,
  `OrderId` int(11) DEFAULT NULL,
  `dttm` datetime DEFAULT current_timestamp(),
  `status` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pays`
--

INSERT INTO `pays` (`PayID`, `customerID`, `image`, `OrderId`, `dttm`, `status`) VALUES
(1, 1, 'cover_60915c4e5d322.jpg', 39, '2022-12-08 13:07:37', 'รอการจัดส่ง'),
(2, 1, 'cover_60915c4e5d322.jpg', 38, '2022-12-08 13:26:29', 'เกิดข้อผิดพลาด'),
(3, 1, 'cover_60915c4e5d322.jpg', 38, '2022-12-08 16:49:12', 'เกิดข้อผิดพลาด'),
(4, 1, 'cover_60915c4e5d322.jpg', 38, '2022-12-08 16:55:50', 'เกิดข้อผิดพลาด'),
(5, 1, 'cover_60915c4e5d322.jpg', 38, '2022-12-08 16:56:20', 'เกิดข้อผิดพลาด'),
(6, 1, 'cover_60915c4e5d322.jpg', 38, '2022-12-08 16:57:20', 'เกิดข้อผิดพลาด'),
(7, 1, 'cover_60915c4e5d322.jpg', 38, '2022-12-08 16:57:31', 'เกิดข้อผิดพลาด'),
(8, 1, 'cover_60915c4e5d322.jpg', 38, '2022-12-08 16:58:06', 'เกิดข้อผิดพลาด'),
(9, 1, '90deb84340ea961ce106b61201ed094c.jpg', 38, '2022-12-08 16:58:15', 'เกิดข้อผิดพลาด'),
(10, 1, 'cover_60915c4e5d322.jpg', 38, '2022-12-08 16:59:51', 'เกิดข้อผิดพลาด'),
(11, 1, 'photo-0019_1.jpg', 38, '2022-12-08 17:00:25', 'เกิดข้อผิดพลาด'),
(12, 1, 'cover_60915c4e5d322.jpg', 38, '2022-12-08 17:02:24', 'เกิดข้อผิดพลาด'),
(13, 1, 'cover_60915c4e5d322.jpg', 38, '2022-12-08 17:03:26', 'เกิดข้อผิดพลาด'),
(14, 1, 'pro15e1f.png', 38, '2022-12-08 17:05:48', 'เกิดข้อผิดพลาด');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `type_id` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(250) DEFAULT NULL,
  `status_id` varchar(10) NOT NULL,
  `price` varchar(10) NOT NULL,
  `stock` varchar(5) NOT NULL,
  `weight_id` varchar(5) NOT NULL,
  `Products_Detail` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `type_id`, `name`, `image`, `status_id`, `price`, `stock`, `weight_id`, `Products_Detail`) VALUES
(2, '2', 'ข้าวหอมมะลิกลางปี', 'upload/หอมมะลิ5.png', '', '185', '12', '3', ''),
(3, '2', 'ข้าวหอมมะลิกใหม่', 'upload/หอมมะลิใหม่5.png', '1', '250', '22', '3', ''),
(4, '3', 'ข้าวเสาไห้ 100%', 'upload/เสาไห้5.png', '1', '96', '4', '3', ''),
(5, '4', 'ข้าวขาว', 'upload/ขาว5.png', '1', '85', '3', '3', ''),
(6, '5', 'ข้าวไรซ์เบอร์รี่', 'upload/ข้าวไรซ์เบอร์รี่5.png', '1', '600', '4', '3', ''),
(7, '', 'test', 'upload/หอมมะลิใหม่5.png', '', '0', '0', '', 'test รายละเอียด2'),
(8, '1', 'test', 'upload/ขาว5.png', '2', '0', '0', '1', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id`, `name`) VALUES
(1, 'จำหน่าย'),
(2, 'ไม่จำหน่าย');

-- --------------------------------------------------------

--
-- Table structure for table `trackings`
--

CREATE TABLE `trackings` (
  `TrackingID` int(10) UNSIGNED NOT NULL,
  `customerID` int(11) DEFAULT NULL,
  `OrderId` int(11) DEFAULT NULL,
  `tracking` varchar(30) DEFAULT NULL,
  `shipping_company` varchar(50) DEFAULT NULL,
  `dttm` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `trackings`
--

INSERT INTO `trackings` (`TrackingID`, `customerID`, `OrderId`, `tracking`, `shipping_company`, `dttm`) VALUES
(18, 1, 39, 'EF582568155TH', ' ไปรษณีย์ไทย', '2022-12-24 15:58:58');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`id`, `name`) VALUES
(1, 'ข้าวเหนียว'),
(2, 'ข้าวหอมมะลิ'),
(3, 'ข้าวเสาไห้'),
(4, 'ข้าวขาว'),
(5, 'ข้าวไรซ์เบอร์รี่');

-- --------------------------------------------------------

--
-- Table structure for table `weight`
--

CREATE TABLE `weight` (
  `id` int(11) NOT NULL,
  `weight` int(5) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `weight`
--

INSERT INTO `weight` (`id`, `weight`, `name`) VALUES
(1, 1, '1 กิโลกรัม'),
(2, 2, '2 กิโลกรัม'),
(3, 5, '5 กิโลกรัม');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `claims`
--
ALTER TABLE `claims`
  ADD PRIMARY KEY (`CliamID`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`new_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`o_id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `pays`
--
ALTER TABLE `pays`
  ADD PRIMARY KEY (`PayID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trackings`
--
ALTER TABLE `trackings`
  ADD PRIMARY KEY (`TrackingID`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `weight`
--
ALTER TABLE `weight`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `claims`
--
ALTER TABLE `claims`
  MODIFY `CliamID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `new_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `o_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `d_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `pays`
--
ALTER TABLE `pays`
  MODIFY `PayID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `trackings`
--
ALTER TABLE `trackings`
  MODIFY `TrackingID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `weight`
--
ALTER TABLE `weight`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
